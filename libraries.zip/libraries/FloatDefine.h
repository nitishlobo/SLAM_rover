#ifndef FloatDefine_h
#define FloatDefine_h



#endif